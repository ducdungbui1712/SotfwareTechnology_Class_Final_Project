﻿
namespace Final_Project.Management_Function
{
    partial class Change_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.tb_imagePath = new System.Windows.Forms.TextBox();
            this.btn_chooseAgain = new System.Windows.Forms.Button();
            this.pb_pdImage = new System.Windows.Forms.PictureBox();
            this.lb_loadImage = new System.Windows.Forms.Label();
            this.tb_pdQty = new System.Windows.Forms.TextBox();
            this.tb_pdPrice = new System.Windows.Forms.TextBox();
            this.tb_pdDetail = new System.Windows.Forms.TextBox();
            this.tb_pdName = new System.Windows.Forms.TextBox();
            this.tb_pdID = new System.Windows.Forms.TextBox();
            this.btn_pdSave = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.combobox_active = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pdImage)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(570, 351);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 34;
            this.label7.Text = "URL";
            // 
            // tb_imagePath
            // 
            this.tb_imagePath.Location = new System.Drawing.Point(572, 389);
            this.tb_imagePath.Name = "tb_imagePath";
            this.tb_imagePath.Size = new System.Drawing.Size(219, 27);
            this.tb_imagePath.TabIndex = 33;
            // 
            // btn_chooseAgain
            // 
            this.btn_chooseAgain.Location = new System.Drawing.Point(812, 384);
            this.btn_chooseAgain.Name = "btn_chooseAgain";
            this.btn_chooseAgain.Size = new System.Drawing.Size(82, 36);
            this.btn_chooseAgain.TabIndex = 32;
            this.btn_chooseAgain.Text = "Choose";
            this.btn_chooseAgain.UseVisualStyleBackColor = true;
            this.btn_chooseAgain.Click += new System.EventHandler(this.btn_chooseAgain_Click);
            // 
            // pb_pdImage
            // 
            this.pb_pdImage.Location = new System.Drawing.Point(572, 145);
            this.pb_pdImage.Name = "pb_pdImage";
            this.pb_pdImage.Size = new System.Drawing.Size(322, 176);
            this.pb_pdImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_pdImage.TabIndex = 31;
            this.pb_pdImage.TabStop = false;
            // 
            // lb_loadImage
            // 
            this.lb_loadImage.AutoSize = true;
            this.lb_loadImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_loadImage.Location = new System.Drawing.Point(570, 122);
            this.lb_loadImage.Name = "lb_loadImage";
            this.lb_loadImage.Size = new System.Drawing.Size(221, 20);
            this.lb_loadImage.TabIndex = 30;
            this.lb_loadImage.Text = "Add an image for product";
            // 
            // tb_pdQty
            // 
            this.tb_pdQty.Location = new System.Drawing.Point(224, 393);
            this.tb_pdQty.Margin = new System.Windows.Forms.Padding(4);
            this.tb_pdQty.Name = "tb_pdQty";
            this.tb_pdQty.Size = new System.Drawing.Size(259, 27);
            this.tb_pdQty.TabIndex = 29;
            // 
            // tb_pdPrice
            // 
            this.tb_pdPrice.Location = new System.Drawing.Point(224, 344);
            this.tb_pdPrice.Margin = new System.Windows.Forms.Padding(4);
            this.tb_pdPrice.Name = "tb_pdPrice";
            this.tb_pdPrice.Size = new System.Drawing.Size(259, 27);
            this.tb_pdPrice.TabIndex = 28;
            // 
            // tb_pdDetail
            // 
            this.tb_pdDetail.Location = new System.Drawing.Point(224, 197);
            this.tb_pdDetail.Margin = new System.Windows.Forms.Padding(4);
            this.tb_pdDetail.Multiline = true;
            this.tb_pdDetail.Name = "tb_pdDetail";
            this.tb_pdDetail.Size = new System.Drawing.Size(259, 124);
            this.tb_pdDetail.TabIndex = 27;
            // 
            // tb_pdName
            // 
            this.tb_pdName.Location = new System.Drawing.Point(224, 151);
            this.tb_pdName.Margin = new System.Windows.Forms.Padding(4);
            this.tb_pdName.Name = "tb_pdName";
            this.tb_pdName.Size = new System.Drawing.Size(259, 27);
            this.tb_pdName.TabIndex = 26;
            // 
            // tb_pdID
            // 
            this.tb_pdID.Location = new System.Drawing.Point(224, 100);
            this.tb_pdID.Margin = new System.Windows.Forms.Padding(4);
            this.tb_pdID.Name = "tb_pdID";
            this.tb_pdID.ReadOnly = true;
            this.tb_pdID.Size = new System.Drawing.Size(259, 27);
            this.tb_pdID.TabIndex = 25;
            // 
            // btn_pdSave
            // 
            this.btn_pdSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pdSave.Location = new System.Drawing.Point(224, 453);
            this.btn_pdSave.Margin = new System.Windows.Forms.Padding(4);
            this.btn_pdSave.Name = "btn_pdSave";
            this.btn_pdSave.Size = new System.Drawing.Size(259, 45);
            this.btn_pdSave.TabIndex = 24;
            this.btn_pdSave.Text = "UPDATE";
            this.btn_pdSave.UseVisualStyleBackColor = true;
            this.btn_pdSave.Click += new System.EventHandler(this.btn_pdSave_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(123, 396);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 347);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 207);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "Detail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(120, 154);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 106);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(236, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 32);
            this.label1.TabIndex = 18;
            this.label1.Text = "UPDATE PRODUCT";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(572, 453);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 45);
            this.button1.TabIndex = 35;
            this.button1.Text = "DELETE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // combobox_active
            // 
            this.combobox_active.FormattingEnabled = true;
            this.combobox_active.Location = new System.Drawing.Point(574, 34);
            this.combobox_active.Name = "combobox_active";
            this.combobox_active.Size = new System.Drawing.Size(145, 28);
            this.combobox_active.TabIndex = 36;
            this.combobox_active.SelectedIndexChanged += new System.EventHandler(this.combobox_active_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 533);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 20);
            this.label8.TabIndex = 37;
            this.label8.Text = "Dung - Nguyen Co., Ltd";
            // 
            // Change_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 562);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.combobox_active);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_imagePath);
            this.Controls.Add(this.btn_chooseAgain);
            this.Controls.Add(this.pb_pdImage);
            this.Controls.Add(this.lb_loadImage);
            this.Controls.Add(this.tb_pdQty);
            this.Controls.Add(this.tb_pdPrice);
            this.Controls.Add(this.tb_pdDetail);
            this.Controls.Add(this.tb_pdName);
            this.Controls.Add(this.tb_pdID);
            this.Controls.Add(this.btn_pdSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Change_Product";
            this.Text = "Change_Product";
            this.Load += new System.EventHandler(this.Change_Product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_pdImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_imagePath;
        private System.Windows.Forms.Button btn_chooseAgain;
        private System.Windows.Forms.PictureBox pb_pdImage;
        private System.Windows.Forms.Label lb_loadImage;
        private System.Windows.Forms.TextBox tb_pdQty;
        private System.Windows.Forms.TextBox tb_pdPrice;
        private System.Windows.Forms.TextBox tb_pdDetail;
        private System.Windows.Forms.TextBox tb_pdName;
        private System.Windows.Forms.TextBox tb_pdID;
        private System.Windows.Forms.Button btn_pdSave;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox combobox_active;
        private System.Windows.Forms.Label label8;
    }
}
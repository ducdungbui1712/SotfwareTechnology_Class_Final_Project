﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Final.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Controllers.Tests
{
    [TestClass()]
    public class ShoppingCartControllerTests
    {
        [TestMethod()]
        public void GetCartTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void AddToCartTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ShowToCartTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void Update_QtyTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void RemoveItemTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void BagCartTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ShoppingSuccessTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void PaymentTest()
        {
            Assert.Fail();
        }
    }
}
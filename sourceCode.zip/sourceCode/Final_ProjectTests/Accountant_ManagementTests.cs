﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Final_Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Tests
{
    [TestClass()]
    public class Accountant_ManagementTests
    {
        [TestMethod()]
        public void Accountant_ManagementTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void Accountant_ManagementTest1()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void logoutTest()
        {
            Assert.Fail();
        }
    }
}